/*
 * newprintf.h
 *
 *  Created on: Jul 23, 2024
 *      Author: loryx
 */

#ifndef INC_NEWPRINTF_H_
#define INC_NEWPRINTF_H_

int _write(int file, char *ptr, int len);

#endif /* INC_NEWPRINTF_H_ */
