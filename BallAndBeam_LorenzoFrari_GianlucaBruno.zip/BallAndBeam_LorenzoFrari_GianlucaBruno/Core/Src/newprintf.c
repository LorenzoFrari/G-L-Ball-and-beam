/*
 * newprintf.c
 *
 *  Created on: Jul 23, 2024
 *      Author: loryx
 */


#include <stdlib.h>
#include <stdio.h>
#include "stm32f4xx.h"

int _write(int file, char *ptr, int len){

	for(int DataIdx = 0; DataIdx < len; DataIdx++){

		ITM_SendChar(*ptr++);
	}
	return len;
}

