/*
 * pid.c
 *
 *  Created on: Jul 25, 2024
 *      Author: loryx
 */

#include "pid.h"


void PID_Init(PID_Typedef *pid, float kp, float ki, float kd){

	/* Clear controller variables */
	pid->integrator = 0.0f;
	pid->prevError  = 0.0f;

	pid->differentiator  = 0.0f;
	pid->prevMeasurement = 0.0f;

	pid->out = 0.0f;

	pid->Ts = 0.01;
	pid->tau = 900;

	pid->limMax = 3.69; /* Per tetha = 155-90 -> alpha = 3.69°*/
	pid->limMin = -5.11; /* Per tetha = 0-90 -> alpha = -5.11°*/

	pid->Kp = kp;
	pid->Ki = ki;
	pid->Kd = kd;
}


void PID_ControlAction(PID_Typedef *pid, float setPoint, float sensorVar){

	/*
		* Error signal
		*/
	    float error = sensorVar - setPoint;


		/*
		* Proportional
		*/
	    float proportional = pid->Kp * error;


		/*
		* Integral
		*/
	    pid->integrator = pid->integrator + 0.5f * pid->Ki * pid->Ts * (error + pid->prevError);

		/* Anti-wind-up via integrator clamping */
	    if (pid->integrator > pid->limMaxInt) {

	        pid->integrator = pid->limMaxInt;

	    } else if (pid->integrator < pid->limMinInt) {

	        pid->integrator = pid->limMinInt;

	    }


		/*
		* Derivative (band-limited differentiator)
		*/

	    pid->differentiator = -(2.0f * pid->Kd * (sensorVar - pid->prevMeasurement)	/* Note: derivative on measurement, therefore minus sign in front of equation! */
	                        + (2.0f * pid->tau - pid->Ts) * pid->differentiator)
	                        / (2.0f * pid->tau + pid->Ts);


		/*
		* Compute output and apply limits
		*/
	    pid->out = proportional + pid->integrator + pid->differentiator;

	    if (pid->out > pid->limMax) {

	        pid->out = pid->limMax;

	    } else if (pid->out < pid->limMin) {

	        pid->out = pid->limMin;

	    }

		/* Store error and measurement for later use */
	    pid->prevError       = error;
	    pid->prevMeasurement = sensorVar;


}

float PID_GetOutput(PID_Typedef *pid){

	return pid->out;
}
