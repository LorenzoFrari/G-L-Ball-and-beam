/*
 * bAb.c
 *
 *  Created on: Sep 6, 2024
 *      Author: loryx
 */


#include "bAb.h"




HAL_StatusTypeDef ball_and_beam_init(ball_and_beam_t *b,PID_Typedef *pid, Servo_t *actuator, vl53l0x_TypeDef *sensor, float beam, float arm){

	HAL_StatusTypeDef ret;

	ret = HAL_OK;

	if(b == NULL || pid == NULL || actuator == NULL || sensor == NULL){

		return HAL_ERROR;
	}

	b->pid = pid;
	b->actuator = actuator;
	b->sensor = sensor;

	b->alpha = 0;
	b->arm = arm;
	b->beam = beam;
	b->theta = 0;

	return ret;
}


float ball_and_beam_get_theta(ball_and_beam_t *b, float alpha){


	b->alpha = alpha;

	/* linear expression */
	b->theta = b->alpha * b->beam / b->arm;

	return b->theta;

}


void ball_and_beam_system(ball_and_beam_t *b){


	VL53L0X_StartMeasurement(&b->sensor->vl53l0x_c); //Effettua la misura

	PID_ControlAction(b->pid, (float)425.0, (float)(b->sensor->RangingData.RangeMilliMeter));
	b->alpha = PID_GetOutput(b->pid);
	b->theta = ball_and_beam_get_theta(b, b->alpha);
	Servo_actuation(b->actuator, b->theta);



}

void ball_and_beam_measurement(ball_and_beam_t *b){


	VL53L0X_GetRangingMeasurementData(&b->sensor->vl53l0x_c, &b->sensor->RangingData);
	VL53L0X_ClearInterruptMask(&b->sensor->vl53l0x_c, VL53L0X_REG_SYSTEM_INTERRUPT_GPIO_NEW_SAMPLE_READY);
	printf("Misura in mm: %u\n", b->sensor->RangingData.RangeMilliMeter);
	HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);

}

