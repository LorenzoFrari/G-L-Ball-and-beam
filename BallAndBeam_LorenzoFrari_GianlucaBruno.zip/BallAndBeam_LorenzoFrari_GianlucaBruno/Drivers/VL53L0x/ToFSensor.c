/*
 * ToFSensor.c
 *
 *  Created on: Jul 23, 2024
 *      Author: loryx
 */

#include "ToFSensor.h"

extern I2C_HandleTypeDef hi2c1; // Necessario per popolare il secondo membro(che è una struttura) della struttura VL53L0x_Dev_t



/* scriverlo al di fuori del metodo dà errore. Pensiamo che le istruzioni di inizializazione devbbano esserre runnate solo
 * quando la struttra VL53L0x_Dev_t sia già stata creata.
 */
void ToFInit(vl53l0x_TypeDef *sensor){

	VL53L0X_Error SensorError; //Usato per il debugging con il printf

	sensor->vl53l0x_c.I2cHandle = &hi2c1;
	sensor->vl53l0x_c.I2cDevAddr = 0x52;

	/* Queste 2 righe sono state aggiunte da noi */
	sensor->vl53l0x_c.comms_type=1; // Setta la comunicazione con I2C
	sensor->vl53l0x_c.comms_speed_khz=100;//  i2c a 400khz prima era 400  variato a 100

	//SensorError = VL53L0X_WaitDeviceBooted( Dev ); Dava HardFault
	//printf(SensorError);
	SensorError = VL53L0X_DataInit( &sensor->vl53l0x_c );
	SensorError = VL53L0X_StaticInit( &sensor->vl53l0x_c );
	//SensorError = VL53L0X_PerformRefCalibration(Dev, &VhvSettings, &PhaseCal);
	//SensorError = VL53L0X_PerformRefSpadManagement(Dev, &refSpadCount, &isApertureSpads);
	//VL53L0X_SetDeviceMode(Dev, VL53L0X_DEVICEMODE_SINGLE_RANGING); // Serve a settarlo in modalita lettura singola
	SensorError = VL53L0X_SetDeviceMode(&sensor->vl53l0x_c, VL53L0X_DEVICEMODE_CONTINUOUS_RANGING); // Questo lo setta in modalita lettura continua

	// Enable/Disable Sigma and Signal check
	SensorError = VL53L0X_SetLimitCheckEnable(&sensor->vl53l0x_c, VL53L0X_CHECKENABLE_SIGMA_FINAL_RANGE, 1);
	SensorError = VL53L0X_SetLimitCheckEnable(&sensor->vl53l0x_c, VL53L0X_CHECKENABLE_SIGNAL_RATE_FINAL_RANGE, 1);
	SensorError = VL53L0X_SetLimitCheckValue(&sensor->vl53l0x_c, VL53L0X_CHECKENABLE_SIGNAL_RATE_FINAL_RANGE, (FixPoint1616_t)(0.1*65536));
	SensorError = VL53L0X_SetLimitCheckValue(&sensor->vl53l0x_c, VL53L0X_CHECKENABLE_SIGMA_FINAL_RANGE, (FixPoint1616_t)(60*65536));
	SensorError = VL53L0X_SetMeasurementTimingBudgetMicroSeconds(&sensor->vl53l0x_c, 33000);
	SensorError = VL53L0X_SetVcselPulsePeriod(&sensor->vl53l0x_c, VL53L0X_VCSEL_PERIOD_PRE_RANGE, 18);
	SensorError = VL53L0X_SetVcselPulsePeriod(&sensor->vl53l0x_c, VL53L0X_VCSEL_PERIOD_FINAL_RANGE, 14);
}

/*
void ToFInit_IT(){

	VL53L0X_Error Status = 0;

	Dev->I2cHandle = &hi2c1;
	Dev->I2cDevAddr = 0x52;

	 Queste 2 righe sono state aggiunte da noi
	Dev->comms_type=1; // Setta la comunicazione con I2C
	Dev->comms_speed_khz=100;//  i2c a 400khz prima era 400  variato a 100


	HAL_NVIC_DisableIRQ(EXTI3_IRQn);

	//Status = VL53L0X_WaitDeviceBooted( Dev );
	Status = VL53L0X_DataInit( Dev );
	Status = VL53L0X_StaticInit( Dev );
	Status = VL53L0X_PerformRefCalibration(Dev, &VhvSettings, &PhaseCal);
	Status = VL53L0X_PerformRefSpadManagement(Dev, &refSpadCount, &isApertureSpads);
	Status = VL53L0X_SetDeviceMode(Dev, VL53L0X_DEVICEMODE_CONTINUOUS_RANGING);
	Status = VL53L0X_StartMeasurement(Dev);

	HAL_NVIC_EnableIRQ(EXTI3_IRQn);

	//VL53L0X_GetRangingMeasurementData(Dev, &RangingData);


}
*/

/* TUTTO CIO CHE SERVE PER ESSERE FELICE è QUESTA FUNZIONE */
void ToFInit_IT(vl53l0x_TypeDef *sensor){

	VL53L0X_Error Status;

	 // center module Struttura che contine info sul sensore (indirizzo, tipo di comunicazione, velocita...)


	sensor->vl53l0x_c.I2cHandle = &hi2c1;
	sensor->vl53l0x_c.I2cDevAddr = 0x52;

	/* Queste 2 righe sono state aggiunte da noi */
	sensor->vl53l0x_c.comms_type = 1; // Setta la comunicazione con I2C
	sensor->vl53l0x_c.comms_speed_khz = 100;//  i2c a 400khz prima era 400  variato a 100

	HAL_NVIC_DisableIRQ(EXTI4_IRQn); // A quanto pare per Settare il sensore correttamente in interrupt mode devi disabilitare IRQ e riabilitarlo alla fine

	Status = VL53L0X_ResetDevice(&sensor->vl53l0x_c); // Ogni volta che runnavo il codide il sensore dava problemi ad inizializzarsi e dovevo spegnere tutto e riaccendere. Questo ha risolto il problema

	Status = VL53L0X_DataInit(&sensor->vl53l0x_c); // Deve essere runnata prima di tutto il resto

	Status = VL53L0X_StaticInit(&sensor->vl53l0x_c);

	Status = VL53L0X_PerformRefCalibration(&sensor->vl53l0x_c, &sensor->VhvSettings, &sensor->PhaseCal);// Da runnare se c'è la cover in vetro

	Status = VL53L0X_PerformRefSpadManagement(&sensor->vl53l0x_c, &sensor->refSpadCount, &sensor->isApertureSpads);// Da runnare se c'è la cover in vetro

	Status = VL53L0X_SetDeviceMode(&sensor->vl53l0x_c, VL53L0X_DEVICEMODE_SINGLE_RANGING);// Si setta in modealita singola

	Status = VL53L0X_SetLimitCheckEnable(&sensor->vl53l0x_c, VL53L0X_CHECKENABLE_SIGMA_FINAL_RANGE, 1);

	Status = VL53L0X_SetLimitCheckEnable(&sensor->vl53l0x_c, VL53L0X_CHECKENABLE_SIGNAL_RATE_FINAL_RANGE, 1);

	Status = VL53L0X_SetLimitCheckValue(&sensor->vl53l0x_c, VL53L0X_CHECKENABLE_SIGNAL_RATE_FINAL_RANGE, (FixPoint1616_t)(0.1*65536));

	Status = VL53L0X_SetLimitCheckValue(&sensor->vl53l0x_c, VL53L0X_CHECKENABLE_SIGMA_FINAL_RANGE, (FixPoint1616_t)(60*65536));

	Status = VL53L0X_SetMeasurementTimingBudgetMicroSeconds(&sensor->vl53l0x_c, 66000); //  timing budget is the time allocated by the user to perform one range measurement. Aumenta il range measurement accuracy.


	Status = VL53L0X_SetGpioConfig(&sensor->vl53l0x_c, 0, VL53L0X_DEVICEMODE_SINGLE_RANGING, VL53L0X_GPIOFUNCTIONALITY_NEW_MEASURE_READY, VL53L0X_INTERRUPTPOLARITY_LOW);

	HAL_NVIC_EnableIRQ(EXTI4_IRQn);

	//Status = VL53L0X_StartMeasurement(Dev); // Forse si cambia -> e invece no.



}

uint16_t getRangeMillimeter(vl53l0x_TypeDef *sensor){

	VL53L0X_PerformSingleRangingMeasurement(&sensor->vl53l0x_c, &sensor->RangingData);
	return sensor->RangingData.RangeMilliMeter;

}

uint16_t getContinousMeasurement(vl53l0x_TypeDef *sensor){

	//VL53L0X_Error Status = WaitMeasurementDataReady(Dev);

	VL53L0X_GetRangingMeasurementData(&sensor->vl53l0x_c, &sensor->RangingData);

	// Clear the interrupt
	VL53L0X_ClearInterruptMask(&sensor->vl53l0x_c, VL53L0X_REG_SYSTEM_INTERRUPT_GPIO_NEW_SAMPLE_READY);
	VL53L0X_PollingDelay(&sensor->vl53l0x_c);

	if(sensor->RangingData.RangeStatus == 0){

		return sensor->RangingData.RangeMilliMeter;
	}

}
