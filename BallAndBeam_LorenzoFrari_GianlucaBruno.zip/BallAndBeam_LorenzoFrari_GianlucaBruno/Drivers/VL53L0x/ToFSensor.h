/*
 * ToFSensor.h
 *
 *  Created on: Jul 23, 2024
 *      Author: loryx
 */

#ifndef VL53L0X_TOFSENSOR_H_
#define VL53L0X_TOFSENSOR_H_

#define TOF_ADDRESS	0x52

#include "main.h"
#include "vl53l0x_api.h"


typedef struct{

	VL53L0X_RangingMeasurementData_t RangingData; // Struttura utilizzata per la misura

	VL53L0X_Dev_t  vl53l0x_c;

	uint32_t refSpadCount;
	uint8_t isApertureSpads;
	uint8_t VhvSettings;
	uint8_t PhaseCal;

}vl53l0x_TypeDef;

void ToFInit(vl53l0x_TypeDef *sensor);
void ToFInit_IT(vl53l0x_TypeDef *sensor);
uint16_t getRangeMillimeter(vl53l0x_TypeDef *sensor);
uint16_t getContinousMeasurement(vl53l0x_TypeDef *sensor);

#endif /* VL53L0X_TOFSENSOR_H_ */
