/*
 * PIDProva.c
 *
 *  Created on: Sep 11, 2024
 *      Author: loryx
 */


#include "PIDProva.h"
#include <math.h>



void pid_init(PID_t *p, float k_p, float k_i, float k_d){

	p->k_p = k_p;
	p->k_i = k_i;
	p->k_d = k_d;
	p->Ts = 0.02;

	p->integral_error = 0;
	p->last_error = 0;

	p->last_updated_ts = 0;

	p->min_output = 1.5017;
	p->max_output = -1.657;


}


void pid_set_setpoint(PID_t *p, float setPoint){


	p->set_point = setPoint;

}


float pid_get_setpoint(PID_t *p){

	return p->set_point;

}


float pid_compute_control_action(PID_t *p, float est_output){


	float delta_T;
	float error, integral_error;
	float u;
	static float last_u;
	float derivative;
	float k_p = p->k_p;

	est_output = 830 - est_output;
	error = pid_get_setpoint(p) - est_output;


	delta_T = p->Ts;

	derivative = (error - p->last_error)/delta_T;

	u = k_p * (error + p->k_i * integral_error + p->k_d * derivative);

	if( u < p->min_output){

		u = p->min_output;
	} else if (u > p->max_output){

		u = p->max_output;
	} else{

		p->integral_error = integral_error;
	}


	last_u = u;

	p->last_error = error;
	pid_update_ts(p);
	return u;

}


void pid_update_ts(PID_t *p){

	p->last_updated_ts = HAL_GetTick();
}
