/*
 * bAb.c
 *
 *  Created on: Sep 6, 2024
 *      Author: loryx
 */


#include "bAb.h"




HAL_StatusTypeDef ball_and_beam_init(ball_and_beam_t *b,PID_Typedef *pid, Servo_t *actuator, vl53l0x_TypeDef *sensor, float beam, float arm, float setPoint){

	HAL_StatusTypeDef ret;

	ret = HAL_OK;

	if(b == NULL || pid == NULL || actuator == NULL || sensor == NULL){

		return HAL_ERROR;
	}

	b->pid = pid;
	b->pid->setPoint = setPoint;
	b->actuator = actuator;
	b->sensor = sensor;

	b->alpha = 0;
	b->arm = arm;
	b->beam = beam;
	b->theta = 0;

	return ret;
}

HAL_StatusTypeDef ball_and_beam_init_2(ball_and_beam_t *b,PID_t *pid, Servo_t *actuator, vl53l0x_TypeDef *sensor, float beam, float arm, float setPoint){

	HAL_StatusTypeDef ret;

	ret = HAL_OK;

	if(b == NULL || pid == NULL || actuator == NULL || sensor == NULL){

		return HAL_ERROR;
	}

	b->pid_2 = pid;
	b->pid_2->set_point = setPoint;
	b->actuator = actuator;
	b->sensor = sensor;

	b->alpha = 0;
	b->arm = arm;
	b->beam = beam;
	b->theta = 0;

	return ret;
}


double ball_and_beam_get_theta(ball_and_beam_t *b, float alpha){


	float alpha_rad;

	b->alpha = alpha;

	alpha_rad = (M_PI*b->alpha)/180;

	double arg_asin =(b->beam/b->arm)*sin(alpha_rad);


	if(arg_asin > 1){


		arg_asin = 1;

	} else if( arg_asin < -1){

		arg_asin = -1;
	}

	/* linear expression */
	//b->theta = b->alpha * b->beam / b->arm;

	/* Non linear expression */
	b->theta = asin(arg_asin);


	b->theta = (b->theta*180)/M_PI;

	return b->theta;

}


void ball_and_beam_system(ball_and_beam_t *b){


	/*Start measurement */
	VL53L0X_StartMeasurement(&b->sensor->vl53l0x_c);

	/*Calculate control action */
	//b->alpha = pid_compute_control_action(b->pid_2, (float)(b->sensor->RangingData.RangeMilliMeter));
	PID_ControlAction(b->pid, (float)(b->sensor->RangingData.RangeMilliMeter));

	b->alpha = PID_GetOutput(b->pid);





	/*Convert alpha into theta(refer to paper) */
	b->theta = ball_and_beam_get_theta(b, b->alpha);

	/*Actuate control action */
	Servo_actuation(b->actuator, b->theta);



}

void ball_and_beam_measurement(ball_and_beam_t *b){

	/*Get measurement when ready */
	VL53L0X_GetRangingMeasurementData(&b->sensor->vl53l0x_c, &b->sensor->RangingData);


	if(b->sensor->RangingData.RangeMilliMeter > 880){

		b->sensor->RangingData.RangeMilliMeter = 880;

	}


	/*Clear mask(refer to sensor's datasheet)*/
	VL53L0X_ClearInterruptMask(&b->sensor->vl53l0x_c, VL53L0X_REG_SYSTEM_INTERRUPT_GPIO_NEW_SAMPLE_READY);



	/////////////////DEBUGGING STUFFS /////////////////////
	printf("Misura in mm: %u\n", b->sensor->RangingData.RangeMilliMeter);
	HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);

}

