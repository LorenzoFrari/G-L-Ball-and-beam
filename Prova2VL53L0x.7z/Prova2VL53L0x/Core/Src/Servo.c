/*
 * Servo.c
 *
 *  Created on: Jul 25, 2024
 *      Author: loryx
 */


#include "Servo.h"
#include "math.h"


inline static uint32_t __servo_conversion(float deg){

	/*can do something more structural but this should work fine for the vast majority of servos*/
	uint32_t ccr = (uint32_t)(45000 + (deg * 1000));
	return ccr;
}


HAL_StatusTypeDef Servo_Init(Servo_t *s, TIM_HandleTypeDef *t, uint32_t frequency, TimerFrequency t_frequency, uint32_t channel){

	HAL_StatusTypeDef ret = HAL_OK;

	uint32_t arr;
	uint16_t psc;

	if(s == NULL || t == NULL){

		return HAL_ERROR;

	}

	s->tim = t;
	s->channel = channel;

	psc = 0;
	arr = (uint32_t)((t_frequency) / (frequency * ((uint32_t)psc + 1))) - 1;

	__HAL_TIM_SET_PRESCALER(t, psc);
	__HAL_TIM_SET_AUTORELOAD(t, arr);

	s->tim->Instance->EGR = TIM_EGR_UG;

	HAL_TIM_PWM_Start(t, channel);

	return ret;
}


void Servo_actuation(Servo_t *s, float theta){

	float deg = theta + (float)90;
	uint32_t ccr = __servo_conversion(deg);
	__HAL_TIM_SET_COMPARE(s->tim, s->channel, ccr);
	s->tim->Instance->EGR = TIM_EGR_UG;


}



