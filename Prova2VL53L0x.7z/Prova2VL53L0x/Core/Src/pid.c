/*
 * pid.c
 *
 *  Created on: Jul 25, 2024
 *      Author: loryx
 */

#include "pid.h"


void PID_Init(PID_Typedef *pid, float kp_in, float ki_in, float kd_in, float kp_out, float ki_out, float kd_out){

	/* Clear controller variables */
	pid->integrator = 0.0f;
	pid->prevError  = 0.0f;

	pid->differentiator  = 0.0f;
	pid->prevMeasurement = 0.0f;

	pid->out = 0.0f;

	pid->error = 0;

	/*Set controller variables */

	pid->limMaxInt = 0.5;
	pid->limMinInt = -0.5;

	pid->Ts = 0.02;
	pid->tau = 900;

	pid->limMax = 2.65 ; /* Per theta = 155-90 -> alpha = 1.5017°*/
	pid->limMin = -2.40; /* Per theta = 0-90 -> alpha = -1.657°*/

	pid->Kp_in = kp_in;
	pid->Ki_in = ki_in;
	pid->Kd_in = kd_in;

	pid->Kp_out = kp_out;
	pid->Ki_out = ki_out;
	pid->Kd_out = kd_out;
}


void PID_ControlAction(PID_Typedef *pid, float sensorVar){


	float Kp;
	float Ki;
	float Kd;

	float fattore_transizione;
	/*
		* Error signal
		*/

		sensorVar = (float)0.88 - (float)((sensorVar)/1000);
	    pid->error = pid->setPoint - sensorVar;

	    if(sensorVar > pid->setPoint - 0.2 && sensorVar < pid->setPoint + 0.2){


	    	Kp = pid->Kp_in;
			Ki = pid->Ki_in;
			Kd = pid->Kd_in;
	    } else{

	    	fattore_transizione = sensorVar / 0.1;


	    	Kp = pid->Kp_out;
			Ki = pid->Ki_out;
			Kd = pid->Kd_out;
	    	//Kp = fattore_transizione * pid->Kp_out + (1.0 - fattore_transizione) * pid->Kp_in;
	    	//Ki = fattore_transizione * pid->Ki_out + (1.0 - fattore_transizione) * pid->Ki_in;
	    	//Kd = fattore_transizione * pid->Kd_out+ (1.0 - fattore_transizione) * pid->Kd_in;
	    }

		/*
		* Proportional
		*/
	    float proportional = Kp * pid->error;


		/*
		* Integral
		*/
	    pid->integrator = pid->integrator + 0.5f * Ki * pid->Ts * (pid->error + pid->prevError);

		/* Anti-wind-up via integrator clamping */
	    if (pid->integrator > pid->limMaxInt) {

	        pid->integrator = pid->limMaxInt;

	    } else if (pid->integrator < pid->limMinInt) {

	        pid->integrator = pid->limMinInt;

	    }


		/*
		* Derivative (band-limited differentiator)
		*/

	    pid->differentiator = -(2.0f * Kd * (sensorVar - pid->prevMeasurement)	/* Note: derivative on measurement, therefore minus sign in front of equation! */
	                        + (2.0f * pid->tau - pid->Ts) * pid->differentiator)
	                        / (2.0f * pid->tau + pid->Ts);


		/*
		* Compute output and apply limits
		*/
	    pid->out = proportional + pid->integrator + pid->differentiator;

	    if (pid->out > pid->limMax) {

	        pid->out = pid->limMax;

	    } else if (pid->out < pid->limMin) {

	        pid->out = pid->limMin;

	    }

		/* Store error and measurement for later use */
	    pid->prevError       = pid->error;
	    pid->prevMeasurement = sensorVar;


}

float PID_GetOutput(PID_Typedef *pid){

	return pid->out;
}
