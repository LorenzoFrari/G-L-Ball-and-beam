/*
 * bAb.h
 *
 *  Created on: Sep 6, 2024
 *      Author: loryx
 */

#ifndef INC_BAB_H_
#define INC_BAB_H_

#include "main.h"

#include <math.h>

#include "PIDProva.h"
#include "../../VL53L0x/ToFSensor.h"
#include "pid.h"
#include "Servo.h"

typedef struct{

	PID_t *pid_2;
	PID_Typedef *pid;
	Servo_t *actuator;
	vl53l0x_TypeDef *sensor;

	float beam;
	float arm;

	float alpha;
	double theta;

	float setPoint;


}ball_and_beam_t;


HAL_StatusTypeDef ball_and_beam_init(ball_and_beam_t *b,PID_Typedef *pid, Servo_t *actuator, vl53l0x_TypeDef *sensor, float beam, float arm, float setPoint);
HAL_StatusTypeDef ball_and_beam_init_2(ball_and_beam_t *b,PID_t *pid, Servo_t *actuator, vl53l0x_TypeDef *sensor, float beam, float arm, float setPoint);
double ball_and_beam_get_theta(ball_and_beam_t *b, float theta);
void ball_and_beam_system(ball_and_beam_t *b);
void ball_and_beam_measurement(ball_and_beam_t *b);



#endif /* INC_BAB_H_ */
