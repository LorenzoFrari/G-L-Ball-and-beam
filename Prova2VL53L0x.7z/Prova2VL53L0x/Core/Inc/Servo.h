/*
 * Servo.h
 *
 *  Created on: Jul 25, 2024
 *      Author: loryx
 */

#ifndef INC_SERVO_H_
#define INC_SERVO_H_

#include <stdint.h>
#include "main.h"

typedef enum{

	TIMER_FREQUENCY_84MHz = 84000000,
	TIMER_FREQUENCY_90MHz = 90000000,
	TIMER_FREQUENCY_180MHz = 180000000

}TimerFrequency;


typedef struct{

	TIM_HandleTypeDef *tim;
	uint32_t ccr;
	uint32_t frequency;
	TimerFrequency t_frequency;
	uint32_t channel;



}Servo_t;




HAL_StatusTypeDef Servo_Init(Servo_t *s, TIM_HandleTypeDef *tim, uint32_t frequency, TimerFrequency t_frequency, uint32_t channel);
void Servo_actuation(Servo_t *s, float tetha);



#endif /* INC_SERVO_H_ */
