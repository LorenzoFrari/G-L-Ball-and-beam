/*
 * PIDProva.h
 *
 *  Created on: Sep 11, 2024
 *      Author: loryx
 */


#include "main.h"

#ifndef INC_PIDPROVA_H_
#define INC_PIDPROVA_H_

typedef struct{


	uint32_t last_updated_ts;
	float set_point;
	float integral_error;
	float last_error;
	float k_p;
	float k_i;
	float k_d;
	float max_output;
	float min_output;
	float neg_dead_zone;
	float pos_dead_zone;
	float Ts;
}PID_t;

void pid_init(PID_t *p, float k_p, float k_i, float k_d);
void pid_set_setpoint(PID_t *p, float setPoint);
float pid_get_setpoint(PID_t *p);
float pid_compute_control_action(PID_t *p, float est_output);
float pid_get_error(PID_t *p);
void pid_update_ts(PID_t *p);

#endif /* INC_PIDPROVA_H_ */
