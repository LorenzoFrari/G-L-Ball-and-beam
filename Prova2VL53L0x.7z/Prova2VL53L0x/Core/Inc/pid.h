/*
 * pid.h
 *
 *  Created on: Jul 25, 2024
 *      Author: loryx
 */

#ifndef INC_PID_H_
#define INC_PID_H_

#include <stdint.h>

typedef struct {

	/*Controller input */

	float error;

	/* Controller gains */
	float Kp_in;
	float Ki_in;
	float Kd_in;

	float Kp_out;
	float Ki_out;
	float Kd_out;

	/* set point */
	/*This will be set into bAb.c (ball_and_beam_init) */

	float setPoint;

	/* Derivative low-pass filter time constant */
	float tau;

	/* Output limits */
	float limMin;
	float limMax;

	/* Integrator limits */
	float limMinInt;
	float limMaxInt;

	/* Sample time (in seconds) */
	float Ts;

	/* Controller "memory" */
	float integrator;
	float prevError;			/* Required for integrator */
	float differentiator;
	float prevMeasurement;		/* Required for differentiator */

	/* Controller output */
	float out;

} PID_Typedef;

void  PID_Init(PID_Typedef *pid, float kp_in, float ki_in, float kd_in, float kp_out, float ki_out, float kd_out);
void PID_ControlAction(PID_Typedef *pid, float measurement);
float PID_GetOutput(PID_Typedef *pid);

#endif /* INC_PID_H_ */
